import React, { useState } from 'react';

function Header() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div>
      <nav className="bg-slate-100 text-sky-600">
        <div className="md:hidden flex items-center justify-between p-4">
          <div className="text-xl font-bold">Empire Akash</div>
          <button
            onClick={toggleMenu}
            className="text-2xl focus:outline-none"
          >
            {isOpen ? (
              <span>&#x2715;</span>
            ) : (
              <span>&#9776;</span>
            )}
          </button>
        </div>
        <ul
          className={`md:flex items-center justify-center flex-wrap transition-transform duration-300 ease-in-out ${
            isOpen ? 'block' : 'hidden'
          }`}
        >
          <li className="mx-2 md:mx-4 p-2 border-b-2 border-yellow-600 transition duration-300 ease-in-out transform hover:bg-emerald-100 hover:text-rose-800 hover:scale-105">
            <a href="/">Home</a>
          </li>
          <li className="mx-2 md:mx-4 p-2 border-b-2 border-yellow-600 transition duration-300 ease-in-out transform hover:bg-emerald-100 hover:text-rose-800 hover:scale-105">
            <a href="/Gallery">Gallery</a>
          </li>
          <li className="mx-2 md:mx-4 p-2 border-b-2 border-yellow-600 transition duration-300 ease-in-out transform hover:bg-emerald-100 hover:text-rose-800 hover:scale-105">
            <a href="/Contact">Contact</a>
          </li>
          <li className="mx-2 md:mx-4 p-2 border-b-2 border-yellow-600 transition duration-300 ease-in-out transform hover:bg-emerald-100 hover:text-black hover:scale-105">
            <a href="/Blog">Blog</a>
          </li>
          <li className="mx-2 md:mx-4 p-2 border-b-2 border-yellow-600 transition duration-300 ease-in-out transform hover:bg-emerald-100 hover:text-rose-800 hover:scale-105">
            <a href="/Support">Support</a>
          </li>
        </ul>
      </nav>
    </div>
  );
}

export default Header;
