import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';

import Layout from './Layout'
import Home from './Components/Home'
import Gallery from './Components/Gallery'
import Contact from './Components/Contact'
import Blog from './Components/Blog'
import Support from './Components/Support'



function App() {
  return (
    <>
        <BrowserRouter>
            <Routes>
                <Route path='/' element = {<Layout />}>
                    <Route path='' element={<Home />} />
                    <Route path='/Gallery' element={<Gallery />} />
                    <Route path='/Contact' element={<Contact />} />
                    <Route path='/Blog' element={<Blog />} />
                    <Route path='/Support' element={<Support />} />
                </Route>
            </Routes>
        </BrowserRouter>
    </>
  );
}

export default App;
